create database labexternal_exp1;
