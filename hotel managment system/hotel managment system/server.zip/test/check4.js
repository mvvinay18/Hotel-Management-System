const { DATE } = require("sequelize");

var date= new DATE()
console.log(date.);